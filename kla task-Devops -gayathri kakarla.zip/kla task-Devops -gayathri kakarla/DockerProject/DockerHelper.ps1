# Build-DockerImage Cmdlet
function Build-DockerImage {
    param (
        [Parameter(Mandatory=$true)]  # Dockerfile parameter, must be provided
        [string]$Dockerfile,

        [Parameter(Mandatory=$true)]  # Tag parameter, must be provided
        [string]$Tag,

        [Parameter(Mandatory=$true)]  # Context parameter, must be provided
        [string]$Context,

        [string]$ComputerName  # Optional parameter to specify a remote computer for execution
    )

    # Construct the Docker build command with the specified parameters
    $dockerCommand = "docker build -f $Dockerfile -t $Tag $Context"

    # If a remote computer name is provided, run the command on that computer
    if ($ComputerName) {
        # Invoke-Command runs the Docker build on the remote machine
        Invoke-Command -ComputerName $ComputerName -ScriptBlock {
            param ($command)
            # Execute the docker command passed as a parameter
            Invoke-Expression $command
        } -ArgumentList $dockerCommand
    } else {
        # If no remote computer is specified, run the command locally
        Invoke-Expression $dockerCommand
    }
}

# Copy-Prerequisites Cmdlet
function Copy-Prerequisites {
    param (
        [Parameter(Mandatory=$true)]  # ComputerName is required to specify the remote machine
        [string]$ComputerName,

        [Parameter(Mandatory=$true)]  # Path parameter specifies the files to copy
        [string[]]$Path,

        [Parameter(Mandatory=$true)]  # Destination parameter specifies where to copy the files on the remote machine
        [string]$Destination
    )

    # Loop through each local path provided in the Path array
    foreach ($localPath in $Path) {
        # Define the remote path on the remote machine using the ComputerName and Destination
        $remotePath = "\\$ComputerName\C$\$Destination" 

        # Copy the file or directory from the local machine to the remote machine
        Copy-Item -Path $localPath -Destination $remotePath -Recurse -Force
    }
}

# Run-DockerContainer Cmdlet
function Run-DockerContainer {
    param (
        [Parameter(Mandatory=$true)]  # ImageName is required to specify the Docker image to run
        [string]$ImageName,

        [string]$ComputerName,  # Optional parameter to specify a remote machine for Docker execution

        [string[]]$DockerParams  # Optional array of additional Docker parameters
    )

    # Construct the Docker run command with the specified image and parameters
    $dockerCommand = "docker run $($DockerParams -join ' ') $ImageName"

    # If a remote computer name is provided, run the command on that machine
    if ($ComputerName) {
        # Invoke-Command runs the Docker run command on the remote machine
        Invoke-Command -ComputerName $ComputerName -ScriptBlock {
            param ($command)
            # Execute the docker command passed as a parameter
            Invoke-Expression $command
        } -ArgumentList $dockerCommand
    } else {
        # If no remote computer is specified, run the command locally
        Invoke-Expression $dockerCommand
    }
}
