# fibonacci.py

import sys
import time

# Function to calculate Fibonacci numbers
def fibonacci(n):
    a, b = 0, 1
    for _ in range(n):
        a, b = b, a + b
    return a

# If argument passed, return the nth Fibonacci number
if len(sys.argv) > 1:
    n = int(sys.argv[1])
    print(f"Fibonacci number at position {n} is {fibonacci(n)}")
else:
    # If no argument, print Fibonacci numbers indefinitely every 0.5 seconds
    i = 0
    while True:
        print(fibonacci(i))
        time.sleep(0.5)
        i += 1
